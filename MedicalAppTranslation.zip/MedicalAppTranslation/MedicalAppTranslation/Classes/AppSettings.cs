﻿using System;

namespace MedicalAppTranslation
{
	public class AppSettings
	{
		public AppSettings ()
		{
		}
		public static Languages AppLanguage { get; set; } 
	}

	public enum Languages { Arabic = 1, English = 2, Hindi = 3, Nepali = 4, Urdu = 5 }
}