﻿using System;
using AVFoundation;
using AudioToolbox;
using Foundation;
using UIKit;

namespace AudioToolbox
{
	public class GameAudioManager
	{

		#region Private Variables
		private AVAudioPlayer backgroundMusic;
		private AVAudioPlayer soundEffect;
		private string backgroundSong="";
		#endregion

		public void PlayBackgroundMusic(string fileName){
			NSUrl songURL;
			//NSUrl song2Url;
			//NSUrl song3Url;



			// Initialize background music
			songURL = new NSUrl("Sounds/" + fileName);
			NSError err;
			backgroundMusic = new AVAudioPlayer (songURL, "mp3", out err);
			//backgroundMusic.Volume = MusicVolume;
			backgroundMusic.FinishedPlaying += delegate { 
				// backgroundMusic.Dispose(); 
				backgroundMusic = null;
			};
			backgroundMusic.NumberOfLoops=0;
			backgroundMusic.Play();
			backgroundSong=fileName;

		}
	}
}
