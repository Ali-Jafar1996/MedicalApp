// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace MedicalAppTranslation
{
	[Register ("middlePage")]
	partial class middlePage
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton buttonFour { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton buttonOne { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton buttonThree { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton buttonTwo { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel topLabel2 { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (buttonFour != null) {
				buttonFour.Dispose ();
				buttonFour = null;
			}
			if (buttonOne != null) {
				buttonOne.Dispose ();
				buttonOne = null;
			}
			if (buttonThree != null) {
				buttonThree.Dispose ();
				buttonThree = null;
			}
			if (buttonTwo != null) {
				buttonTwo.Dispose ();
				buttonTwo = null;
			}
			if (topLabel2 != null) {
				topLabel2.Dispose ();
				topLabel2 = null;
			}
		}
	}
}
