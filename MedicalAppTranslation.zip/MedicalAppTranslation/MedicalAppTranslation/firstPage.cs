using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace MedicalAppTranslation
{
	partial class firstPage : UIViewController
	{
		public firstPage (IntPtr handle) : base (handle)
		{
		}

		partial void englishChange (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.English;
		}

		partial void arabicChange (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.Arabic;
		}
	}
}
