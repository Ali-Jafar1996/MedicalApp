using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace MedicalAppTranslation
{
	partial class middlePage : UIViewController
	{
		public middlePage (IntPtr handle) : base (handle)
		{
		}

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();

			var lang = "";
			if (AppSettings.AppLanguage == Languages.Arabic)
				lang = "ar";
			else
				lang = "en";
			//lang = "ar";
			var path = NSBundle.MainBundle.PathForResource (lang, "lproj");
			var b = NSBundle.FromPath (path);
			var str = b.LocalizedString ("Please select the profession", "");
			topLabel2.Text = str;

			var str2 = b.LocalizedString ("Front Desk", "");
			buttonOne.SetTitle(str2, UIControlState.Normal);

			var str3 = b.LocalizedString ("Nurse", "");
			buttonTwo.SetTitle(str3, UIControlState.Normal);

			var str4 = b.LocalizedString ("Doctor", "");
			buttonThree.SetTitle(str4, UIControlState.Normal);

			var str5 = b.LocalizedString ("Pharmacist", "");
			buttonFour.SetTitle(str5, UIControlState.Normal);
		}
	}
}
