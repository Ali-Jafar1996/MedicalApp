// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace MedicalAppTranslation
{
	[Register ("secondPage")]
	partial class secondPage
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel topLabel { get; set; }

		[Action ("hindi2:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void hindi2 (UIButton sender);

		[Action ("hindiChange:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void hindiChange (UIButton sender);

		[Action ("nepali2:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void nepali2 (UIButton sender);

		[Action ("nepaliChange:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void nepaliChange (UIButton sender);

		[Action ("pakChange:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void pakChange (UIButton sender);

		[Action ("playHindi:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void playHindi (UIButton sender);

		[Action ("playNepali:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void playNepali (UIButton sender);

		[Action ("playUrdu:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void playUrdu (UIButton sender);

		[Action ("urdu2:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void urdu2 (UIButton sender);

		void ReleaseDesignerOutlets ()
		{
			if (topLabel != null) {
				topLabel.Dispose ();
				topLabel = null;
			}
		}
	}
}
