using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace MedicalAppTranslation
{
	partial class secondPage : UIViewController
	{
		public secondPage (IntPtr handle) : base (handle)
		{
		}
			

		partial void playHindi (UIButton sender)
		{
			var manager = new AudioToolbox.GameAudioManager();
			manager.PlayBackgroundMusic("hindi.mp3");
		}

		partial void playNepali (UIButton sender)
		{
			var manager = new AudioToolbox.GameAudioManager();
			manager.PlayBackgroundMusic("nepali.mp3");
		}

		partial void playUrdu (UIButton sender)
		{
			var manager = new AudioToolbox.GameAudioManager();
			manager.PlayBackgroundMusic("urdu.mp3");
		}


		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();

			var lang = "";
			if (AppSettings.AppLanguage == Languages.Hindi)
				lang = "ar";
			else
				lang = "en";
			//lang = "ar";
			var path = NSBundle.MainBundle.PathForResource (lang, "lproj");
			var b = NSBundle.FromPath (path);
			var str = b.LocalizedString ("Please select the patient's language", "");
			topLabel.Text = str;
		}

		partial void hindiChange (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.Hindi;
		}

		partial void nepaliChange (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.Nepali;
		}

		partial void pakChange (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.Urdu;
		}

		partial void hindi2 (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.Hindi;
		}

		partial void nepali2 (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.Nepali;
		}

		partial void urdu2 (UIButton sender)
		{
			AppSettings.AppLanguage = Languages.Urdu;
		}
	}
}
