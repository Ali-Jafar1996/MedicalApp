using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace MedicalAppTranslation
{
	partial class sound1 : UIButton
	{
		public sound1 (IntPtr handle) : base (handle)
		{
		}

		public static AppDelegate App {
			get { return (AppDelegate)UIApplication.SharedApplication.Delegate; }
		}
	}
}
