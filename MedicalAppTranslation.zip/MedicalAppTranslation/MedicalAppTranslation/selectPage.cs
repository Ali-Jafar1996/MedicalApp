using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace MedicalAppTranslation
{
	partial class selectPage : UIViewController
	{
		public selectPage (IntPtr handle) : base (handle)
		{
		}

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();

			var lang = "";
			if (AppSettings.AppLanguage == Languages.Hindi)
				lang = "hi";
			else if (AppSettings.AppLanguage == Languages.Nepali)
				lang = "ne";
			else
				lang = "pk";
			//lang = "hi";
			var path = NSBundle.MainBundle.PathForResource (lang, "lproj");
			var b = NSBundle.FromPath (path);
			var str = b.LocalizedString ("Please select the patient's language", "");
			thisLabel.Text = str;
		}
	}
}
